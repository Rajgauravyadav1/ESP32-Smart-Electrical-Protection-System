#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <PZEM004Tv30.h>

const char* ssid = "YOUR_WIFI_NAME";
const char* password = "YOUR_WIFI_PASSWORD";

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

PZEM004Tv30 pzem(Serial2, 16, 17);

#define RELAY_PIN 26

WebServer server(80);

bool relayState = false;

float voltage = 0;
float current = 0;
float power = 0;

void updateOLED()
{
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);

  display.setCursor(0,0);
  display.println("ESP32 POWER");

  display.print("LOAD: ");
  display.println(relayState ? "ON" : "OFF");

  display.print("V: ");
  display.println(voltage);

  display.print("I: ");
  display.println(current);

  display.print("P: ");
  display.println(power);

  display.display();
}

void readPZEM()
{
  voltage = pzem.voltage();
  current = pzem.current();
  power = pzem.power();

  if(isnan(voltage)) voltage = 0;
  if(isnan(current)) current = 0;
  if(isnan(power)) power = 0;
}

String webpage()
{
  String page = "";

  page += "<html><body>";
  page += "<h1>ESP32 POWER MONITOR</h1>";

  if(relayState)
  {
    page += "<h2>LOAD : ON</h2>";
    page += "<a href='/off'><button>TURN OFF</button></a>";
  }
  else
  {
    page += "<h2>LOAD : OFF</h2>";
    page += "<a href='/on'><button>TURN ON</button></a>";
  }

  page += "<h2>Voltage: " + String(voltage) + " V</h2>";
  page += "<h2>Current: " + String(current) + " A</h2>";
  page += "<h2>Power: " + String(power) + " W</h2>";

  page += "</body></html>";

  return page;
}

void handleRoot()
{
  readPZEM();
  updateOLED();
  server.send(200, "text/html", webpage());
}

void handleON()
{
  relayState = true;
  digitalWrite(RELAY_PIN, LOW);
  handleRoot();
}

void handleOFF()
{
  relayState = false;
  digitalWrite(RELAY_PIN, HIGH);
  handleRoot();
}

void setup()
{
  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH);

  Wire.begin(21,22);

  display.begin(0x3C, true);

  WiFi.begin(ssid, password);

  while(WiFi.status() != WL_CONNECTED)
  {
    delay(500);
  }

  server.on("/", handleRoot);
  server.on("/on", handleON);
  server.on("/off", handleOFF);

  server.begin();
}

void loop()
{
  server.handleClient();
}
